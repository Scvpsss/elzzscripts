#!/bin/bash

IP=$1
USER=$2
PASS=$3
PORT=$4
INSTALLER="/usr/bin/lunabotwa/waduk.sh"

# Cek file waduk.sh
if [ ! -f "$INSTALLER" ]; then
    echo "❌ File $INSTALLER tidak ditemukan!"
    exit 1
fi

# Pastikan sshpass ada
if ! command -v sshpass >/dev/null 2>&1; then
    apt update -y && apt install -y sshpass
fi

echo "📦 Mengirim waduk.sh ke VPS $IP..."
sshpass -p "$PASS" scp -P $PORT -o StrictHostKeyChecking=no "$INSTALLER" ${USER}@$IP:/root/

echo "🚀 Menjalankan waduk.sh di VPS $IP..."
sshpass -p "$PASS" ssh -p $PORT -o StrictHostKeyChecking=no ${USER}@$IP "chmod +x /root/waduk.sh && /root/waduk.sh"

echo "✅ Instalasi selesai di VPS $IP"
