const fs = require('fs');
const crypto = require('crypto');
const { Client } = require('ssh2');

module.exports = async ({ isAdmin, isOwner, args, lunaticreply }) => {
    if (!isAdmin && !isOwner) return lunaticreply("❌ ```KHUSUS LUNATIC``` ");

    // Ambil prefix
    let prefix = '!';
    try {
        const pf = JSON.parse(fs.readFileSync('./avars/prefix.json'));
        prefix = pf.prefix || '!';
    } catch {}

    // Argumen WA: expired + target VPS
    const [expired, targetVps] = args;
    if (!expired || !targetVps) {
        return lunaticreply(
            `❗ *Format Salah!*\n\n*Contoh:*\n${prefix}trivle 30 sgp1\n\n*Example:*\n${prefix}trivle 60 vps-tunnel`
        );
    }

    // Generate username random
    const namaakun = "trivl" + crypto.randomBytes(3).toString('hex');
    const kuotaGB = 2; // default kuota 2GB
    const limitIP = 1; // default 1 IP

    // Ambil data VPS
    const vpsPath = './avars/vpsdata.json';
    if (!fs.existsSync(vpsPath)) return lunaticreply('❌ ```DATA VPS KOSONG```');

    const vpsData = JSON.parse(fs.readFileSync(vpsPath));
    const target = vpsData[targetVps];
    if (!target) {
        return lunaticreply(`❌ VPS "${targetVps}" tidak ditemukan!\nGunakan: *${prefix}listvps*`);
    }

    // Eksekusi ke VPS
    const conn = new Client();
    conn.on('ready', () => {
        const cmd = `bash /usr/bin/LTBOTVPN/triallVLE ${namaakun} ${kuotaGB} ${limitIP} ${expired}`;
        conn.exec(cmd, (err, stream) => {
            if (err) return lunaticreply('❌ Gagal eksekusi command di VPS');

            let output = '';
            stream.on('data', chunk => output += chunk.toString());
            stream.stderr.on('data', errChunk => output += errChunk.toString());
            stream.on('close', () => {
                conn.end();
                if (!output.trim()) {
                    return lunaticreply('⚠️ Tidak ada output. Cek manual di VPS.');
                }

                const beautify = '```' + output.trim() + '```';
                lunaticreply(`✅ *Trial VLESS Berhasil dibuat:*\n\n${beautify}`);
            });
        });
    }).on('error', err => {
        lunaticreply(`❌ Gagal konek ke VPS: ${err.message}`);
    }).connect({
        host: target.ip,
        port: 22,
        username: 'root',
        password: target.pass
    });
};