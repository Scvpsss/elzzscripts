
// DIAN PERMANA MAHREZ 
// BANDUNG BARAT || BOJONG JAMBU || SAGULING
// INDONESIA 
// CONTACK : wa.me/+6283197765857


const axios = require('axios')

module.exports = async ({ q, lunaticreply }) => {
    if (!q) return lunaticreply("*EXAMPLE:* ai apa itu bot?")

    lunaticreply(mess.wait)

    try {
        const url = new URL("https://yw85opafq6.execute-api.us-east-1.amazonaws.com/default/boss_mode_15aug")
        url.search = new URLSearchParams({
            text: q,
            country: "Europe",
            user_id: "Av0SkyG00D"
        }).toString()

        const response = await axios.get(url.toString(), {
            headers: {
                "User-Agent": "Mozilla/5.0 (Linux; Android 11; Infinix) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.0.0 Mobile Safari/537.36",
                Referer: "https://www.ai4chat.co/pages/riddle-generator"
            }
        })

        if (response.status !== 200 || !response.data) {
            throw new Error("API error atau response kosong")
        }

        lunaticreply(`🤖 *AI LUNATIC:*\n\n${response.data}`)
    } catch (error) {
        console.error("❌ Error AI:", error)
        lunaticreply(mess.error)
    }
}
