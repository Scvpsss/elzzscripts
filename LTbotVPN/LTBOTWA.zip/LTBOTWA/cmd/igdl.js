const axios = require('axios');

module.exports = async ({ q, lunatix, msg, sender, lunaticreply }) => {
    if (!q) return lunaticreply("⚠️ *Mana link Instagram-nya?*\nContoh: !igdl https://www.instagram.com/reel/xxxx");

    lunaticreply("⏳ Tunggu sebentar, sedang mengunduh...");

    try {
        const apiUrl = `https://www.velyn.biz.id/api/downloader/instagram?url=${encodeURIComponent(q)}`;
        const response = await axios.get(apiUrl);
        const { data } = response.data;

        if (!data || !data.url || !data.url[0]) return lunaticreply("❌ Media tidak ditemukan atau link salah.");

        const mediaUrl = data.url[0];
        const metadata = data.metadata;

        const mediaMsg = metadata.isVideo
            ? {
                video: { url: mediaUrl },
                caption: `🎬 *Instagram Reel*\n\n` +
                         `👤 *Username:* ${metadata.username}\n` +
                         `❤️ *Likes:* ${metadata.like}\n` +
                         `💬 *Comments:* ${metadata.comment}\n\n` +
                         `📝 *Caption:* ${metadata.caption || '-'}\n🔗 ${q}`
              }
            : {
                image: { url: mediaUrl },
                caption: `🖼️ *Instagram Post*\n\n` +
                         `👤 *Username:* ${metadata.username}\n` +
                         `❤️ *Likes:* ${metadata.like}\n\n` +
                         `📝 *Caption:* ${metadata.caption || '-'}\n🔗 ${q}`
              };

        await lunatix.sendMessage(sender, mediaMsg, { quoted: msg });
    } catch (err) {
        console.error("❌ Error IG Downloader:", err.message);
        lunaticreply("❌ Gagal mengambil media Instagram.\nPastikan link valid dan coba lagi.");
    }
};
