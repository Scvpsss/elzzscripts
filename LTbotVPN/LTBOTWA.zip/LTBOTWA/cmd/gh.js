const axios = require('axios');

module.exports = async ({ q, lunatix, msg, sender, lunaticreply, isAdmin }) => {
    // Batasi hanya untuk owner
    if (!isAdmin) return lunaticreply("❌ Perintah ini hanya untuk *owner bot*!");

    if (!q) return lunaticreply("❗ *Contoh penggunaan:* !gh luna");

    lunaticreply("🔍 Mencari repositori GitHub...");

    try {
        const url = `https://api.github.com/users/${q}/repos?per_page=5&sort=updated`;
        const res = await axios.get(url, {
            headers: {
                'User-Agent': 'LunatixBot'
            }
        });

        const repos = res.data;

        if (!repos.length) {
            return lunaticreply(`❌ Tidak ada repositori ditemukan untuk *${q}*`);
        }

        let text = `🔎 *Repositori GitHub: ${q}*\n\n`;
        for (let i = 0; i < repos.length; i++) {
            const repo = repos[i];
            text += `*${i + 1}. ${repo.name}*\n📎 ${repo.html_url}\n📄 ${repo.description || '-'}\n\n`;
        }

        lunaticreply(text.trim());

    } catch (err) {
        console.error("❌ GitHub Error:", err.message);
        if (err.response?.status === 404) {
            lunaticreply("❌ Username tidak ditemukan.");
        } else if (err.response?.status === 403) {
            lunaticreply("🚫 Terlalu banyak permintaan ke GitHub, coba beberapa saat lagi.");
        } else {
            lunaticreply("❌ Gagal mengambil data dari GitHub.");
        }
    }
};
