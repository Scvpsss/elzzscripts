const fs = require('fs');
const axios = require('axios');
const crypto = require('crypto');

const OS_MAP = {
  'ubu22.04': 'ubuntu-22-04-x64',
  'ubu24.04': 'ubuntu-24-04-x64',
  'ubu24.10': 'ubuntu-24-10-x64',
  'deb11':    'debian-11-x64',
  'deb12':    'debian-12-x64',
};

const REGION_MAP = {
  'sgp1': 'Singapore',
  'ams3': 'Amsterdam',
  'fra1': 'Frankfurt',
  'nyc3': 'New York',
  'sfo3': 'San Fran',
  'blr1': 'Bangalore',
};

const SIZE_MAP = {
  '1/2':  { slug: 's-1vcpu-1gb', label: '1GB / 2TB' },
  '2/3':  { slug: 's-1vcpu-2gb', label: '2GB / 3TB' },
  '4/4':  { slug: 's-2vcpu-4gb', label: '4GB / 4TB' },
  '8/5':  { slug: 's-4vcpu-8gb', label: '8GB / 5TB' },
  '16/6': { slug: 's-6vcpu-16gb', label: '16GB / 6TB' },
};

function generatePassword(length = 12) {
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let pass = '';
  while (pass.length < length) {
    const byte = crypto.randomBytes(1)[0];
    if (byte < chars.length * 4) pass += chars[byte % chars.length];
  }
  return pass;
}

const rand = n => crypto.randomBytes(n).toString('hex');

module.exports = async ctx => {
  const { args, lunaticreply, isAdmin } = ctx;
  if (!isAdmin) return lunaticreply('❌ Khusus admin!');

  const [osAlias, regionAlias, sizeAlias] = args;
  if (!osAlias || !regionAlias || !sizeAlias)
    return lunaticreply('❗ Format: !buatvps <os> <region> <ram/bw>\nContoh: !buatvps ubu24.04 sgp1 2/3');

  const imageSlug = OS_MAP[osAlias.toLowerCase()];
  const regionSlug = regionAlias.toLowerCase();
  const regionName = REGION_MAP[regionSlug];
  const size = SIZE_MAP[sizeAlias.toLowerCase()];

  if (!imageSlug) return lunaticreply('❌ OS tidak dikenal!');
  if (!regionName) return lunaticreply('❌ Region tidak dikenal!');
  if (!size) return lunaticreply('❌ RAM/BW tidak valid! Contoh: 2/3, 4/4, dll');

  const tokenPath = './avars/token.json';
  if (!fs.existsSync(tokenPath)) return lunaticreply('❌ Token tidak ditemukan!');
  const { digitalocean } = JSON.parse(fs.readFileSync(tokenPath));
  if (!digitalocean) return lunaticreply('❌ Token DigitalOcean kosong!');

  const password = generatePassword(12);
  const name = `bot-${osAlias}-${rand(2)}`;

  lunaticreply(`🚀 Membuat VPS...\nNama   : ${name}\nOS     : ${osAlias}\nRegion : ${regionName}\nRAM    : ${size.label}`);

  try {
    const create = await axios.post('https://api.digitalocean.com/v2/droplets', {
      name,
      region: regionSlug,
      size: size.slug,
      image: imageSlug,
      ipv6: true,
      monitoring: true,
      user_data: `#cloud-config
chpasswd:
  list: |
    root:${password}
  expire: False
ssh_pwauth: True`,
      tags: ['bot-created']
    }, {
      headers: {
        Authorization: `Bearer ${digitalocean}`,
        'Content-Type': 'application/json'
      }
    });

    const dropletId = create.data.droplet.id;

    // 🕐 Tunggu max 30 detik untuk IP
    let ipAddress = null;
    for (let i = 0; i < 6; i++) {
      await new Promise(res => setTimeout(res, 5000)); // tunggu 5 detik
      const { data } = await axios.get(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
        headers: { Authorization: `Bearer ${digitalocean}` }
      });
      const net = data.droplet.networks.v4.find(n => n.type === 'public');
      if (net) {
        ipAddress = net.ip_address;
        break;
      }
    }

    if (!ipAddress) {
      return lunaticreply(`✅ *VPS DIBUAT*\nNama    : ${name}\nRAM     : ${size.label}\nPassword: ${password}\n⚠️ IP belum tersedia, cek dashboard DO.`);
    }

    lunaticreply(`✅ *VPS DIBUAT*\nNama    : ${name}\nIP VPS  : ${ipAddress}\nRAM     : ${size.label}\nPassword: ${password}`);
  } catch (e) {
    console.error('❌ Create VPS error:', e.response?.data || e.message);
    lunaticreply('❌ Gagal membuat VPS. Coba lagi nanti.');
  }
};
