const fs = require('fs')
const path = require('path')
const ownerPath = path.join(__dirname, '../avars/owner.json')

module.exports = async ({ lunatix, msg, sender, lunaticreply, isAdmin }) => {
    if (!isAdmin) return lunaticreply("❌ Khusus owner bot!");

    const owner = JSON.parse(fs.readFileSync(ownerPath))

    if (!owner.length) return lunaticreply('⚠️ Belum ada owner yang terdaftar.');

    const list = owner.map((id, i) => `${i + 1}. wa.me/${id.replace(/[^0-9]/g, '')}`).join('\n')
    lunaticreply(`📋 *Daftar Owner:*\n\n${list}`)
}
