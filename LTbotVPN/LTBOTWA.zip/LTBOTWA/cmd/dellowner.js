const fs = require('fs')
const path = require('path')
const ownerPath = path.join(__dirname, '../avars/owner.json')

module.exports = async ({ lunaticreply, args, isAdmin }) => {
    if (!isAdmin) return lunaticreply('❌ Perintah ini hanya untuk Owner.');

    if (!args[0]) return lunaticreply('⚠️ Masukkan nomor yang ingin dihapus!\nContoh: !delowner 628xxx');

    const nomor = args[0].replace(/[^0-9]/g, '')
    let owner = JSON.parse(fs.readFileSync(ownerPath))

    if (!owner.includes(nomor)) return lunaticreply('❌ Nomor tersebut belum terdaftar sebagai owner.');

    owner = owner.filter(n => n !== nomor)
    fs.writeFileSync(ownerPath, JSON.stringify(owner, null, 2))

    lunaticreply(`✅ Nomor ${nomor} berhasil dihapus dari daftar owner.`)
}
