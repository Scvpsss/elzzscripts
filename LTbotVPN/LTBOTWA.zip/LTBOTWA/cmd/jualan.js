module.exports = async ({ lunatix, isOwner, lunaticreply }) => {
if (!isOwner) return lunaticreply("❌ ```KHUSUS LT KANG BASH JS PYTHON🗿``` ");
const teksPromosi = `
‎🌐✨ 𝐙𝐄𝐂𝐓 𝐒𝐓𝐎𝐑𝐄 ✨🌐
‎━━━━━━━━━━━━━━━━━━━
‎🔥 Layanan VPN Premium 🔥
‎⚡ SSH • WS • UDP
‎⚡ XRAY (VMESS / VLESS) • gRPC
‎⚡ TROJAN • WS • GRPC
‎━━━━━━━━━━━━━━━━━━━
‎🌏 Server: Singapura 🇸🇬
‎🏢 ISP: Digital Ocean
‎━━━━━━━━━━━━━━━━━━━
‎💸 Harga Paket:
‎💠 7 Hari — Rp3.000
‎💠 15 Hari  — Rp5.000
‎💠 1 Bulan — Rp10.000
‎💠 2 Bulan — Rp18.000
‎━━━━━━━━━━━━━━━━━━━
‎🌟 Kelebihan VPN Premium:
‎✅ Trial Wajib Sebelum Beli
‎✅ Support VC & Game Online
‎✅ Full Garansi Sampai Expired
‎✅ Amanah & Terpercaya
‎✅ Bonus Config Premium
‎✅ Bebas Request Config
‎━━━━━━━━━━━━━━━━━━━
‎💰 Metode Pembayaran:
‎💳 DANA
‎💳 QRIS (All Payment)
‎━━━━━━━━━━━━━━━━━━━
‎📩 Order Sekarang!
‎📱 WhatsApp : wa.me/6287880697490
‎👥 Grup WA : https://chat.whatsapp.com/DlBDb5h3zaOA13uBNQsg7u?mode=ems_copy_t
‎🛡️ Saluran Testimoni : https://whatsapp.com/channel/0029Vb6GcFpBlHpfF1jHn23q
‎━━━━━━━━━━━━━━━━━━━ ‎‎`;
try {
const groups = await lunatix.groupFetchAllParticipating();
let sukses = 0, gagal = 0;
for (const id in groups) {
try {
await lunatix.sendMessage(id, { text: teksPromosi });
await new Promise(res => setTimeout(res, 1500)); // delay biar anti banned/spam
sukses++
} catch (e) {
gagal++
}
}
lunaticreply(`✅ Promosi dikirim ke ${sukses} grup.\n❌ Gagal kirim ke ${gagal} grup.`);
} catch (err) {
console.error("❌ Error broadcast promosi:", err);
lunaticreply("❌ Gagal mengirim promosi.");
}
};